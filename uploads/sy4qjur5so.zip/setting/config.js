module.exports = {
  BOT_TOKEN: "8634883266:AAE5-D9hYixJ99wdIgXM6YQ_zJvMRui_Fkw",
  OWNER_ID: ["8263158603"],
};