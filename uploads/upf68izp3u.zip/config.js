module.exports = {
  BOT_TOKEN: "8963528794:AAHbcaM5MD-bGCdDjs0gpRbkAU_3VRQxQ3E",
  OWNER_ID: ["8286316637"],
  
  /// NGGAK TAU BUAT APA POKOK NYA BUAT START WINGS🗿🗿
  tokeninstall: "revan",
  bash: "bash <(curl https://raw.githubusercontent.com/zerodevxc/revan/refs/heads/main/install.sh)",
  
  // Domain Reseller Panel 
  domain: 'https://alvinzofficialrobot.serverprivv.my.id/', // domain
  plta: 'ptla_udoUpvAan6QIdWJjFKnaT9ydoveNn9AeiiKivevT8sJ', // pltc reseller 
  pltc: 'ptlc_qUuwDGXm791r0NINZYmieHEVRIoISe59Se084nUIJS2', // pltc reseller 
  
  // Domain Khusus Admin
  domainv2: 'https://alvinzofficialrobot.serverprivv.my.id/', // domain
  pltav2: 'ptla_udoUpvAan6QIdWJjFKnaT9ydoveNn9AeiiKivevT8sJ', // plta khusus admin
  pltcv2: 'ptlc_qUuwDGXm791r0NINZYmieHEVRIoISe59Se084nUIJS2', // pltc khusus admin 
  
  loc: '1', // 
  eggs: '15'
};