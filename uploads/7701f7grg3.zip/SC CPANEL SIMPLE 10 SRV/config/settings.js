const fs = require('fs');

global.prefix = '/';

// Konfigurasi Bot
global.namabot = '𝐍𝐨𝐯𝐚𝐚𝐂𝐏𝐀𝐍𝐄𝐋'
global.idowner = '7406337254'
global.apikeyhost = ``

// --- Konfigurasi Server 1 ---
global.domain = 'https:/' // Isi domain panel
global.plta = 'ptla' // Isi API Key PLTA
global.pltc = 'ptlc' // Isi API Key PLTC
global.loc = '1' // Lokasi default
global.eggs = '15' // Egg default 
global.nests = '5' // Nests Default 

// --- Konfigurasi Server 2 ---
global.domainV2 = 'https://' 
global.pltaV2 = 'ptla' 
global.pltcV2 = 'ptlc'
global.locV2 = '1' // Lokasi default Server 2
global.eggsV2 = '15' // Egg default Server 2
global.nestsV2 = '5' // Nests Default Server 2

// --- Konfigurasi Server 3 ---
global.domainV3 = 'https://' 
global.pltaV3 = 'ptla'
global.pltcV3 = 'ptlc'
global.locV3 = '1' 
global.eggsV3 = '15'
global.nestsV3 = '5'

// --- Konfigurasi Server 4 ---
global.domainV4 = 'https://.' 
global.pltaV4 = 'ptla'
global.pltcV4 = 'ptlc'
global.locV4 = '1' 
global.eggsV4 = '15' 
global.nestsV4 = '5'

// --- Konfigurasi Server 5 ---
global.domainV5 = 'https://' 
global.pltaV5 = 'ptla_'
global.pltcV5 = 'ptlc_'
global.locV5 = '1' 
global.eggsV5 = '15' 
global.nestsV5 = '5'

// --- Konfigurasi Server 6 ---
global.domainV6 = 'https://' 
global.pltaV6 = 'ptla_'
global.pltcV6 = 'ptlc_'
global.locV6 = '1' 
global.eggsV6 = '15' 
global.nestsV6 = '5'

// --- Konfigurasi Server 7 ---
global.domainV7 = 'https://' 
global.pltaV7 = 'ptla_'
global.pltcV7 = 'ptlc_'
global.locV7 = '1' 
global.eggsV7 = '15' 
global.nestsV7 = '5'

// --- Konfigurasi Server 8 (BARU) ---
global.domainV8 = 'https://' 
global.pltaV8 = 'ptla_'
global.pltcV8 = 'ptlc_'
global.locV8 = '1' 
global.eggsV8 = '15' 
global.nestsV8 = '5'

// --- Konfigurasi Server 9 (BARU) ---
global.domainV9 = 'https://' 
global.pltaV9 = 'ptla_'
global.pltcV9 = 'ptlc_'
global.locV9 = '1' 
global.eggsV9 = '15' 
global.nestsV9 = '5'

// --- Konfigurasi Server 10 (BARU) ---
global.domainV10 = 'https://' 
global.pltaV10 = 'ptla_'
global.pltcV10 = 'ptlc_'
global.locV10 = '1' 
global.eggsV10 = '15' 
global.nestsV10 = '5'

global.thumbnailPath = "https://files.catbox.moe/153ljc.jpg"
global.paket = "https://files.catbox.moe/nbfba0.jpg"
global.startMenuPhoto = "https://files.catbox.moe/lo55w3.jpg" 


global.subdomain = { 
        "jhonaley.net": {
        zone: "e67db64db8ec671f105c77ee521daa37",
        apitoken: '-eNyMkEo9Wy1_n92YhDZ3QBDlVihX-1VGCUzfrj8',
        },
        "jhonaley.web.id": {
        zone: "dd00b76d94af1e8d5f37f4253f77861f",
        apitoken: 'MHXAKlSaWbFcCLDqo7t-A-KFx1N89vUOwjvSgVTt',
        },
    "naell.my.id": { 
        zone: "090a81422da7b258cdf3ef02de1e4ca3",
        apitoken: 'HTLdfWAdDalNoz5x3-Pe4MLWGVgxKRq6ZMVz4vl0',
    },
    "naell.cloud": { 
        zone: "1b662cae2a8214a8468c97fb552070d0",
        apitoken: 'EX4ezkgaSvD3JeXeKoDQzfmqI_Mh0yUek7WmDO0u',
    },
    "privateeserverr.my.id": {
        zone: "2b47743c5a3afecde36ffa0f52073270",
        apitoken: '2ltJMUmL2QZ-H3IQ0NGM8n84zxoJlU1D8Wwj26AB',
    },
    "publicserverr.my.id": {
        zone: "b23d82b98aa932317c93571a3846240a",
        apitoken: '2ltJMUmL2QZ-H3IQ0NGM8n84zxoJlU1D8Wwj26AB',
    },
}; 

global.mess = {
    wait: "⏳ Sabar ya... lagi diproses, jangan ditinggal dulu!",
    success: "✅ Mantap! Permintaan kamu berhasil diproses.",
    on: "🟢 Oke! Fitur ini sekarang aktif, silakan gunakan.",
    off: "🔴 Sip! Fitur ini dimatikan sementara.",
    text: "✍️ Ups! Kamu belum kasih teks, coba isi dulu ya.",
    link: "🔗 Hmmm... link-nya mana? Kirim dulu yang valid ya.",
    fitur: "⚠️ Wah, fitur ini lagi error. Sabar dulu atau lapor ke owner ya!",
    seller: "🛒 Eits! Fitur ini khusus buat Seller & Owner aja ya.",
    atmin: "🛡️ Maaf, fitur ini hanya dapat digunakan oleh Admin atau Owner!",
    private: "📩 Fitur ini cuma bisa dipakai di chat pribadi, kirim lewat private dong!",
    owner: "👑 Waduh! Cuma yang punya bot alias owner yang bisa akses ini.",
    admin: "🛑 Fitur ini hanya bisa digunakan oleh admin grup!",
    group: "👥 Fitur ini hanya bisa digunakan dalam grup!"
};
